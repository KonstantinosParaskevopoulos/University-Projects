#include"my_8_bit.h"

int main(){
	Program P1;
	P1.PRINT("HELLO WORLD");
	P1.GOTO("fa");
	P1.end();
	
	return 0;
}
